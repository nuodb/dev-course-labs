package com.nuodb.training;

import java.util.Properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.nuodb.jdbc.DataSource;
import com.nuodb.training.DatabaseConfig.DataSourceConfig;

/**
 * Configuration class that initializes a NuoDB DataSource for use in the tests.
 * <p>
 * By using Spring Boot to drive the tests:
 * <ul>
 * <li>The tests will automatically load the SQL scripts in
 * {@code src/test/resources} to initialize the database into a known state for
 * the tests.
 * <li>Create a test DataSource to use in the tests.
 * </ul>
 * <p>
 * Alternatively use {@link TestBaseNoSpring} to perform tests without using any
 * Spring at all.
 */
@Configuration
// Tell Spring Boot to create a DataSourceConfig bean and initialize it from
// its associated properties (see DataSourceConfig below)
@EnableConfigurationProperties(DataSourceConfig.class)
public class DatabaseConfig {

	Environment env;

	public DatabaseConfig(Environment env) {
		this.env = env;
	}

	/**
	 * Container for Spring Boot's data source properties. At runtime Spring Boot
	 * will create an instance and (due to the {@code @ConfigurationProperties})
	 * assign any {@code spring.datasource.xxx} property to the {@code xxx} property
	 * in this class. Thus {@code spring.datasource.url} is assigned by calling
	 * {@link DataSourceConfig#setUrl(String)}. Property setters are mandatory for
	 * this to work. To support NuoDB's data source, we save the values to an
	 * internal Properties object.
	 * <p>
	 * The annotation {@code @EnableConfigurationProperties(DataSourceConfig.class)}
	 * above is also required to make this work.
	 */
	@ConfigurationProperties(prefix = "spring.datasource")
	public static class DataSourceConfig {
		private Properties properties = new Properties();

		public void setUrl(String url) {
			properties.setProperty("url", url);
		}

		public void setUsername(String username) {
			properties.setProperty("username", username);
		}

		public void setPassword(String password) {
			properties.setProperty("password", password);
		}

		public Properties getProperties() {
			return properties;
		}
	}

	/**
	 * Create the data source using the properties in the {@link DataSourceConfig}
	 * bean.
	 * 
	 * @param dsc A data-source configuration instance initialized from Spring
	 *            Boot's usual DataSource properties.
	 * @return An initialized NuoDB Data Source instance.
	 */
	@Bean
	public DataSource dataSource(DataSourceConfig dsc) {
		return new DataSource(dsc.getProperties());
	}
}
