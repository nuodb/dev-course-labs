package com.nuodb.training;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class JarUploader {

	// TODO-01: Set these constants ... then run as a Java Application
	private static final String JAR_FILE_PATH = //
			"/Users/paulchapman/Work/training/courses/labs/14-java-procs-solution/target/14-java-procs-solution-1.0.0.RELEASE.jar";
	private static final String CLASSID = "lab14";

	public static void main(String[] args) {
		SpringApplication.run(JarUploader.class, args);
	}

	@Component
	class Uploader implements CommandLineRunner {

		@Autowired
		DataSource dataSource;

		@Override
		public void run(String... args) throws Exception {
			try (Connection conn = dataSource.getConnection()) {
				upload(conn, new File(JAR_FILE_PATH), CLASSID);
			}

			System.out.println("CREATE JAVACLASS " + CLASSID + " succeeded");
		}

	}

	public static void upload(Connection conn, File jarFile, String classId) throws Exception {

		try (PreparedStatement pstmt = conn.prepareStatement("CREATE JAVACLASS " + classId + " FROM ?")) {
			Blob jarData = conn.createBlob();
			OutputStream blobStream = jarData.setBinaryStream(1);

			try (FileInputStream in = new FileInputStream(jarFile)) {
				int read = 0;
				byte[] buffer = new byte[10240];
				while ((read = in.read(buffer)) > 0) // Copy jar contents
					blobStream.write(buffer, 0, read); // into Blob
				pstmt.setBlob(1, jarData);
				pstmt.execute();
			}
		}
	}

}
